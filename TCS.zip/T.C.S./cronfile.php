<?php 
    /*Heres where you add the head & header*/
echo'
<span class="txt1" >Finished The ';
include("classes/0anime.php");
include("classes/0book.php");
include("classes/0game.php");
include("classes/0movie.php");
include("classes/0music.php");
include("classes/0software.php");
include("classes/0tv.php");
echo'</span>';
?>
