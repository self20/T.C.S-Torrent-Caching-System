
    <!--Here's where you add the head & header-->
         
<form class="txt1" action="search.php" method="post">
<input type="text" name="search" placeholder="Search">
<input type="submit" value="Search">

<br>
<br>
<strong class="txt1">All of the hashes have been rewritten to make the code truly piracy-free & avoid unpleasantness with the copyright trolls.</strong>
<br><br>
<span class="txt1"> Till now the system has been able to index <?php include("classes/totaltrrs.php"); ?></span>
</form><br><br><br>
<h1 id="th1">About The Script:</h1>
<br>
<?php $nontent ='<span>
<li>The Script Runs As A Cron Job, you can update the DB list yourself by clicking <a href="https://tcs.elbrado.cf/cache/cronfile.php">here</a></li><br>
<li>Here\'s where you add your description</li><br><span>'; 

$biggarhtexto = ucwords($nontent);
echo $biggarhtexto;

?>
</body></html>
